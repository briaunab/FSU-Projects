import java.util.Scanner;

public class StringEx4{
    public static void main(String[] ags) {
        
       //Declare varibles
       String city1 = "", city2 = "";
       char letter;
       
       //Create Scanner object
       Scanner keyboard = new Scanner(System.in);
       
       //prompt user for two cities
       System.out.print("Enter two cities: ");
       
       //read city1 from keyboard
       city1 = keyboard.next().toUpperCase();
       
       //read city2 from keyboard
       city2 = keyboard.nextLine();
       
       
       //Print city1 to counsel
       System.out.println("City 1 is: " + city1);
       
       
       //Parse first character in city1
       letter = Character.toLowerCase(city1.charAt(0));
       
       //Print out character
       System.out.println("City 1 char: " + letter);
       
       //Print city2 to counsel
       System.out.println("City 2 is: " + city2);
        
        
        
        
    }//end main method
}//end of class