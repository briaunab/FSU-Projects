import java.util.Scanner;
public class StringEx1{
    
    public static void main(String []args) {
        
        //Declare variables
        String fullName = "";
        String firstName = "";
        String lastName = "";
        String middle = "";
        char middleInt;
        
        
        //Create Scanner object
        Scanner input = new Scanner (System.in);
        
        
        //Prompt user for full name
        System.out.print("Please enter your full name: ");
        
        
        //Read their full name from keyboard
        firstName = input.next();
        
        //Read middle name
        middle = input.next();
        
        //Read last name to the end of the line
        lastName = input.nextLine();
        
     
        //Display first name and middle initial to console
        System.out.println("Your first name is: " + firstName);
        System.out.println(firstName.toUpperCase() + "'s middle initial is: " + middle.charAt(0)); 
        
        
        
        
        
    
        
    }//end of class
    
}//end of main method