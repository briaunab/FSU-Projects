public class Random{
    /*Main method */
    
    public static void main(String[] args) {
        int number 1 = (int)(Math.random()*10)
        int number 2 = 50 + (int)
    }
}