//Student Name: Briauna Brown
//Course Number: COP2258
//Date: 12/9/2016
//Assignment Name: DateFormat2

import java.util.*;
public class DateFormat2 {
    public static void main(String[] args) {
        
        //Declare variables
        int month;
        int day;
        int year;
        int dateFormat;
        String birthdate = "";
        String month2 = "";
        
        //Create Scanner Object
        Scanner input = new Scanner (System.in);
         //Prompt user for date format option
         System.out.print("Which format would you prefer for the date? Select 1 - mm/dd/yyyy or 2 - Month dd, yyyy]: ");
         
         //Read dateFormat from keyboard
         dateFormat = input.nextInt();
         
         //Begin if / else statement
         if (dateFormat == 1) {
             
        
        //Prompt user for day
        System.out.print("Please enter the day you were born represented as two digits: ");
        
        //Read day from keyboard
        day = input.nextInt();
        
        //Prompt user for the month
        System.out.print("Please enter the month you were born represented as two digits: ");
        
        //Read month from keyboard
        month = input.nextInt();
        
        //Prompt user for the year
        System.out.print("Please enter the year you were born represented as four digits: ");
        
        //Read year from keyboard
        year = input.nextInt();
        
        //Call the formatter method to format the birthdate
        birthdate = formatter(day, month, year);
        
        //Print formatted date
        System.out.print("Here is the date in the following formate (mm/dd/yy): " + birthdate + "\n");
         }
          
        else if (dateFormat == 2) {
            //Prompt user for day
        System.out.print("Please enter the day you were born represented as two digits: ");
        
        //Read day from keyboard
        day = input.nextInt();
        
        //Prompt user for the month
        System.out.print("Please enter the NAME of month you were born in (ex. July): ");
        
        //Read month from keyboard
        month2 = input.next();
        
        //Prompt user for the year
        System.out.print("Please enter the year you were born represented as four digits: ");
        
        //Read year from keyboard
        year = input.nextInt();
        
        //Call the formatter method to format the birthdate
        birthdate = formatter2(month2, day, year);
        
        //Print formatted date
        System.out.print("Here is the date in the following formate (mm/dd/yy): " + birthdate + "\n");
        }
         
         
         
         
    }//end of main
    
    //Purpose of Method: Format the birth date
    
    public static String formatter (int d , int m , int y) {
        
        String birthdate = m + "/" + d + "/" + y;
        return birthdate;
    
        
    }//End of formatter method
    public static String formatter2 (String m, int d, int y ) {
        String birthdate = m + " " + d + ", " + y;
        return birthdate;
    }//End of formatter2 method
    
}//End of class