import java.util.*;
public class EvenOdd {
    public static void main(String []args){
        
        //Declare and initialize variable
        int evenNum = 0, oddNum = 0, tempNum = 0;
        String playAgain = "";
        
        do {
        
                //Prompt user for list of positive integers
                System.out.println("Please enter a list of positive numbers separated by a space.");
                System.out.println("(Enter a negative number after all numbers ave been entered.)");
                
                
                //Declare Scanner object
                Scanner input = new Scanner (System.in);
                
                //Read list of integers
                tempNum = input.nextInt();
                
                //Process the list of numbers using a while loop
                while (tempNum >= 0 ) {
                    
                        if(tempNum %2 == 0){
                            evenNum++;
                        }//end if statement mod 2
                        
                        else {
                            oddNum++;
                        }//end else
                        tempNum = input.nextInt();
                }//End of while loop
                
                //Print Results
                System.out.println("\nThe total number of even positive integers is: " + evenNum);
                System.out.println("The total number of odd integers is: " + oddNum);
                
                //Prompt the user to determine whether to play again
                System.out.print("Would you like to play again? Please type 'yes' or 'no': ");
                
                //Read user's response
                playAgain = input.next();
                
                //Resetting counters
                
                evenNum = 0;
                oddNum = 0;
        
        } while (playAgain.equalsIgnoreCase("yes"));
        
        
    }//end of main
}//end of class