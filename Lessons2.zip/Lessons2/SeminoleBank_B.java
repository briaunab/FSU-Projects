import java.util.Scanner; 

public class SeminoleBank_B {
    
    public static void main(String[] ags) {
        
        //Declare variables
        int accountNumber;
        String menuChoice;
        int deposit = 0;
        int withdrawal = 0;
        String newBalance;
        Double currentBalance = 1000.00;
        
        //Initialize Scanner
        Scanner input =  new Scanner (System.in);
        
        //Display Welcome Message
        System.out.println("****************************************************************************************");
        System.out.println("\t\t\tWelcome to Seminole Bank!");
        System.out.println("****************************************************************************************");
        
        //Prompt user for account number
        System.out.print("Please enter your 5-digit account number: ");
        
        //Read account number
        accountNumber = input.nextInt();
        
        // Display thank you message
        System.out.println("Thank you!!");
    do {
        
                    //Prompt user for transaction type
                    System.out.print("Enter D for deposit, W for withdrawal, B for balance, X to exit the menu: ");
                    
                    //Read menu choice
                    menuChoice = input.next().toUpperCase();
                    
                    
                    //Process menu until user enters X (Use a WHILE loop with an “if…else if” or a “switch”)
                        
                                //If statement for Deposit option
                        
                                if ( menuChoice.equals("D")){
                                    System.out.print("Enter the amount of Deposit: ");
                                    deposit = input.nextInt();
                                    currentBalance = (currentBalance + deposit);
                                }//End of Deposit
                                
                                
                                //If statement for Withdrawal
                                else if (menuChoice.equals("W")) {
                                    System.out.print("Enter the amount of Withdrawal: ");
                                    withdrawal = input.nextInt();
                                    currentBalance = (currentBalance + withdrawal);
                                }//End of Withdrawal
                                
                                
                                //If statement for Current Balance
                                else if (menuChoice.equals("B")) {
                                    System.out.printf("Account Number: " + accountNumber + " has a current balance of: $%.2f" , currentBalance);
                                }//End of Current Balance
                                
                                
                                //If Statement for Error 
                                else {
                                    System.out.println("ERROR: Please enter a D, W, B, or X: ");
                        }//End error
                        
                        //Prompt Again
                        System.out.print("");
                        System.out.print("\n\nEnter D for deposit, W for withdrawal, B for balance, X to exit the menu: ");
                        menuChoice = input.next().toUpperCase();
                    
                    } while ( !menuChoice.equals("X"));
            
    //Display thank you message
    System.out.println("Thank you for being a loyal Seminole Bank customer!");
    
    }//End of main
}//End of class 