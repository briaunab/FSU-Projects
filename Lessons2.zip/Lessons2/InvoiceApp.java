import java.util.Scanner;
 
public class InvoiceApp
{
    public static void main(String[] args)
    {
        //Declare variables and Scanner object
        int customerType;
        double discountAmount;
        double discountPercentage;
        double subtotal;
        double total;
        Scanner input = new Scanner(System.in);
        
        //Display a welcome message
        System.out.println("****************************************************************************************");
        System.out.println("\t\t\tWelcome to the Invoice Calculator\n");
        System.out.println("****************************************************************************************");
 
        //Prompt user for customer type
        System.out.print("Please enter the customer type (Enter 1 for Silver, 2 for Gold, or 3 for Platinum: ");
        

        //Read customer type
        customerType =input.nextInt();

           
        //Prompt user for subtotal   
        System.out.print("Please enter the subtotal: ");

        
        //Read subtotal
        subtotal = .0;
        subtotal = input.nextDouble();
        
        //Declare Discount Percentage
        discountPercentage = .00;
        
        //Apply customer type percentages
        
        if ((customerType < 1)  || (customerType > 3)) {
            discountPercentage = .05;
        }
        
        
        //Customer Type 1
        
        else if (customerType == 1) {
            
            if (subtotal >= 500) {
                discountPercentage = .20;
                
            }
                
            else if ((subtotal < 500) && (subtotal >=250)) {
                discountPercentage = .15;
            }
            
            else if ((subtotal < 250) && (subtotal >= 100)) {
                discountPercentage = .10;
            }
            
            else if (subtotal < 100) {
                discountPercentage = 0;
                }
                
            }
            
        //Customer type 2
        else if (customerType == 2) {
            discountPercentage = .20;
        }
        
        //Customer type 3
        
        else if (customerType == 3) {
            if (subtotal >= 500){
                discountPercentage = .50;
            }
            
            else if (subtotal < 500) {
                discountPercentage = .40;
            }
        }

        
        //Calculate Invoice Total
        discountAmount = subtotal * discountPercentage;
        total = subtotal - discountAmount;

        //Format and display the results
        System.out.println("****************************************************************************************");
        System.out.println("\t\t\t\tINVOICE REPORT:\n");
        System.out.printf("\t\tSubtotal: %.2f\n", subtotal);
        System.out.printf("\t\tCustomer type: %d\n", customerType);
        System.out.printf("\t\tDiscount percent: %.2f\n", discountPercentage);
        System.out.printf("\t\tDiscount amount: %.2f\n", discountAmount);
        System.out.printf("\t\tTotal: %.2f\n", total);
        
        
        //Display thank you message
        
        System.out.println("\t\t\t\tThank you!!\n");
        System.out.println("****************************************************************************************");
        


       
    }//end of main
}//end of class0