import java.util.Scanner; 

public class SumofNum1 {
    
    public static void main(String[] ags) {
        
        //Declare varianles
        int sum, val1, val2;
        
        //Create Scanner object
        Scanner input = new Scanner (System.in);
        
        //prompt user for two integers
        System.out.println("Please enter two integers: ");
        
        //Read integers 
        val1 = input.nextInt();
        val2 = input.nextInt();
        
        //find the sum of two integers
        sum = val1 + val2;
        
        //Read answer
        System.out.print("The sum of the two integers is: " + sum);
        
        
        
        
    }//end of main
    
    
    
}//end of class