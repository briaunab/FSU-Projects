//Student Name: Briauna Brown
//Course Number: COP2258
//Date: 12/6/2016
//Assignment: Lesson 8 Bank Account

import java.util.Scanner;

public class BankAccount{
    

        //Main Function
        public static void main(String []args){
        
                //Declare and initialize a variable for balance to $5000.
                
                char menuChoice;
                char choice;
                double balance = 5000.00;
                
                
               
                //Call the welecomeMessage() function to display on screen
                
                welcomeMessage();
                
                //Call AccountInfo 
                int accountNumber = accountInfo();
                
                
                do{
                        //Call the function to display the menu and prompt the user for their choice 
                        
                        //HINT:  The displayMenu() function must return the choice back to main()!  In main(), dont forget to assign the call statement to a variable.
                        
                        //Call the displayMenu() function AND assign it to a variable
                        
                         choice = displayMenu();
                                     
                    
                        //Start the switch() statement to determine which function is called based on the users choice
                        switch(choice){
                            
                                //Case (If the menu choice is D)
                                case 'D':
                                        balance = depositFunds(balance);
                                        break;
                                        
                    
                    
                                //Case (If the menu choice is W)
                                        //Call the withdrawFunds(balance) function AND assign it to a variable
                                case 'W':
                                        balance = withdrawFunds(balance);
                                        break;
                            
                                //Case (If the menu choice is B)
                                        //Call the checkBalance(account number, balance) function
                                case 'B':
                                        checkBalance(accountNumber , balance); 
                                        break;
                            
                                //Case (If the menu choice is X)
                                case 'X':
                                        break;
                            
                                //Default for user error handling
                                default: System.out.println("ERROR: Please enter a D, W, B, or X: \n");
                                
                        }//end of switch     
             
                }while(choice != 'X');  
        
            
            //Display final message
                System.out.print("");
                System.out.print("Thank you for being a loyal Seminole Bank Customer!\n");
                System.out.print("");
            
        }//end of main
        
             
        /**************************************************** FUNCTION DEFINITIONS *****************************************************/

         //Display welcome message 
         public static void welcomeMessage(){
                System.out.print("********************************************\n");
                System.out.print("\tWelcome to Seminole Bank! \n");
                System.out.print("********************************************\n");
         }//end of welcomeMessage
         
         //Prompt and Read users account number.  RETURN the account number to main().
         public static int accountInfo() {
                //Prompt account number and read it to counsel
                System.out.println("Please enter your 5-digit Account Number: \n");
                        
                Scanner input = new Scanner(System.in);
                int accountNumber = input.nextInt();
                System.out.print("Thank you!!\n");
                return accountNumber;
                        
        }//End accountInfo
         
        
         //Display menu choices to the user and Read the users banking choice.  RETURN the users menu choice to main().
        public static char displayMenu(){
                //Prompt for menuchoice
                System.out.print("Enter D for deposit, W for withdrawal, B for balance, X to exit the menu: ");
                                        
                //Declare Scanner object
                Scanner keyboard = new Scanner (System.in);
                        
                //Read menuChoice               
                char menuChoice = keyboard.next().charAt(0);
                menuChoice = Character.toUpperCase(menuChoice);
                return menuChoice;
        }//End Display Menu
         
         
         //Prompt the user for the amount to deposit and Read deposit amount.  Update the balance and RETURN the balance to main().
         public static double depositFunds(double balance){
                 //Prompt User for deposit
                 System.out.print("Enter the amount of deposit: \n");
                 
                 //Scanner object
                 Scanner input = new Scanner(System.in);
                 //Read deposit amount
                 double deposit = input.nextDouble();
                 balance = balance + deposit;
                 //Return balance for deposit
                 return balance;
                          
         }//end of depositFunds
         
    
         //Prompt the user for the amount to withdraw and Read withdrawal amount.  Update the balance and RETURN the balance to main().
         public static double withdrawFunds (double balance){
             System.out.print("Enter the amount of withdrawl: \n");
                 
                 //Scanner object
                 Scanner input = new Scanner(System.in);
                 //Read withdraw amount
                 double withdraw = input.nextDouble();
                 balance = balance - withdraw;
                 //Return balance for withdrawal
                 return balance;
                //Don't forget to declare local Scanner object to read withdrawal amount.
             
         }//end of withdrawFunds
     
         //Display the balance and DO NOT RETURN anything to main().
         public static void checkBalance(int accountNumber , double balance){
             System.out.printf("Account Number: " + accountNumber +  " has a current balance of : $%.2f " , balance);
             System.out.println(""); 
         }//end of checkBalance
                  
        /**************************************************END OF FUNCTION DEFINITIONS **************************************************/
    
    
}//end of BankAccount Class
