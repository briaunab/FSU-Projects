import java.util.Scanner; 

public class SumofNum2 {
    
    public static void main(String[] ags) {
        
        //Declare varianles
        int  val1, val2;
        
        //Create Scanner object
        Scanner input = new Scanner (System.in);
        
        //prompt user for two integers
        System.out.println("Please enter two integers: ");
        
        //Read integers 
        val1 = input.nextInt();
        val2 = input.nextInt();
        
        //Checkup
        System.out.println("I am in the main method!");
        
        //Call statement for the sumOfTwo method (void return type)
        sumOfTwo(val1, val2); //This is called a passby value
        
        //Checkout
        System.out.println("I am back in the main method!");
        
    }//end of main
    
    //Purpose: Calculate Sum and Print to Counsel (int names do not have to be the same as the int names above)
     public static void sumOfTwo(int first, int second) {
         
        //Declare variable
        int sum;
         
        //find the sum of two integers
        sum = first + second;
        
        //Read answer
        System.out.print("The sum of the two integers is: " + sum+ "\n");
        
         
     }//end of sumofTwo method
    
}//end of class