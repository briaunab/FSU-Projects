import java.util.Scanner;

public class StringEx4{
    public static void main(String[] ags) {
        
       //Declare varibles
       String city1 = "", city2 = "";
       char letter;
       
       //Create Scanner object
       Scanner keyboard = new Scanner(System.in);
       
       //prompt user for two cities
       System.out.print("Enter two cities: ");
       
       //read city1 from keyboard
       city1 = keyboard.next().toUpperCase();
       
       //read city2 from keyboard
       city2 = keyboard.nextLine().trim();
       
       
       //Compare two cities and print them in order
       
       if(city1.CompareTo(city2) < 0) {
           System.out.println( city1 + " " + city2);
           
       }
       
       else if (city1.compareTo(city2)>0) {
           System.out.println( city2 + " " + city1);
           
       }
       
       else {
           System.out.println( city1 + " " + city2 + " are equal!");
       }
       
    }//End of main

}//End of class
       