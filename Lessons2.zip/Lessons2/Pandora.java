import java.util.Scanner; //needed to use Scanner for input

public class Pandora {
  public static void main(String[] args) {
   
        //Declare variables
        String lastName = "";
        int menuChoice;
        String musicChannel="";
        int artistChannel;
        
        //Create a Scanner object
        
        Scanner input =  new Scanner (System.in);
    
        //Display the Opening Statement which includes the Pandora Menu
        
        System.out.println("******************************WELCOME TO PANDORA******************************\n\n");
        System.out.print("\t\t\t\t PANDORA MENU: \n");
        System.out.print("\t\t\t1 - Create New Pandora Channel\n");
        System.out.print("\t\t\t2 - Play Pandora Channel\n");
        System.out.print("\t\t\t3 - Exit Pandora\n\n");
        System.out.println("******************************************************************************\n\n");
        
        
        //Prompt the user for their last name and menu choice option  
        
        
        System.out.println("Please enter your last name followed by your Pandora Menu Choice: \n\n");
        
    
        //Read the user's lastname and read the user's menu choice; Parse string if necessary!
        
        lastName = input.next().toUpperCase(); //Read name from keyboard and change to upper case
        menuChoice = input.nextInt(); //Reads the music choice from keyboard

        //Control statement (if()/else if() or switch()) that is based on the user's menu choice
                //process the user's menu choice (options:  1, 2, 3, other)
                
                //Option ONE (IF)
                 if (menuChoice == 1) {
                    System.out.println("You have selected the CREATE NEW PANDORA CHANNEL menu item!\n\n");
                    //Enter name of channel for Option one
                    System.out.print("Please enter the name of your channel: \n\n");
                    //Read channel name and capitalize
                    musicChannel = input.next().toUpperCase();
                    //Display results for Option ONE
                    System.out.println("");
                    System.out.print("You have successfully created the following PANDORA channel: " + musicChannel);
                    System.out.println("");
                    System.out.println("");
        }
        
        // End Option ONE
        
                //Option TWO 
                  else if (menuChoice == 2){
                    //Display user selections and channel lists for Option TWO
                    System.out.print("You have selected PLAY PANDORA CHANNEL menu item! \n");
                    System.out.print("The user " + lastName.toUpperCase() + " has created the following channels: \n");
                    System.out.print("1. Beyonce\n\n" + "2. Chance the Rapper \n\n" + "3. Ariana Grande\n\n" + "4. Jazmine Sullivan\n\n" + "5. Drake\n\n" + "6. Kendrick Lamar\n\n" + "7. Vybez Kartel\n\n" + "8. D.R.A.M\n\n" + "9. Frank Ocean\n\n" + "10. dvsn\n\n\n"); 
                    //Prompt user for the channel they would like to select(1-10)
                    System.out.print("Which channel would you like to listen to? (Enter any number between 1-10): \n\n");
                      
                      //Read channel input
                      artistChannel = input.nextInt();
                      
                      //Print statement based on input
                      
                      switch (artistChannel) {
                      
                        case 1 :
                            System.out.print("You are now listening to: BEYONCE\n\n");
                            break;
                            
                        case 2 :
                            System.out.print("You are now listening to: CHANCE THE RAPPER\n\n");
                            break;
                            
                        case 3 :
                            System.out.print("You are now listening to: ARIANA GRANDE\n\n");
                            break;
                            
                        case 4 :
                            System.out.print("You are now listening to: JAZMINE SULLIVAN\n\n");
                            break;
                            
                        case 5 :
                            System.out.print("You are now listening to: DRAKE\n\n");
                            break;
                            
                        case 6 :
                            System.out.println("You are now listening to: KENDRICK LAMAR\n\n");
                            break;
                            
                        case 7 :
                            System.out.println("You are now listening to: VYBEZ KARTEL\n\n");
                            break;
                            
                        case 8 :
                            System.out.print("You are now listening to: D.R.A.M\n\n");
                            break;
                            
                        case 9 :
                            System.out.print("You are now listening to: FRANK OCEAN\n\n");
                           break;
                            
                        case 10 :
                            System.out.print("You are now listening to: DVSN\n\n");
                            break;
                           
       }
    }//End Option TWO
       
       //Option THREE 
       
       else if (menuChoice == 3){
         //Display the EXIT PANDORA selection
         System.out.println("");
         System.out.print("You have selected EXIT PANDORA menu item!\n\n");
       }//End Option THREE
      
        //Display Thank you message
        System.out.println("");
         System.out.println(lastName.toUpperCase() + "! Thank you for being a valued listener!\n\n\n");
         System.out.println("****************************** GOODBYE PANDORA LISTENER ******************************");
         
  }//end of main
}//end of class